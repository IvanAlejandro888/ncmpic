/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout;
    QLabel *label_2;
    QTabWidget *tabWidget;
    QWidget *tab;
    QVBoxLayout *verticalLayout_3;
    QTextEdit *Ctxt;
    QGridLayout *gridLayout;
    QPushButton *C;
    QPushButton *CPaste;
    QPushButton *CCopy;
    QPushButton *CClear;
    QWidget *tab_2;
    QVBoxLayout *verticalLayout_4;
    QTextEdit *Dtxt;
    QGridLayout *gridLayout_2;
    QPushButton *DClear;
    QPushButton *DPaste;
    QPushButton *DCopy;
    QPushButton *D;
    QPushButton *Limpiar;
    QLabel *label;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(439, 375);
        QIcon icon;
        icon.addFile(QString::fromUtf8("../../\303\215cono/NCMPIC_icono.png"), QSize(), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        verticalLayout = new QVBoxLayout(centralWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QStringLiteral("label_2"));

        verticalLayout->addWidget(label_2);

        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        verticalLayout_3 = new QVBoxLayout(tab);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        Ctxt = new QTextEdit(tab);
        Ctxt->setObjectName(QStringLiteral("Ctxt"));

        verticalLayout_3->addWidget(Ctxt);

        gridLayout = new QGridLayout();
        gridLayout->setSpacing(6);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(-1, 0, -1, -1);
        C = new QPushButton(tab);
        C->setObjectName(QStringLiteral("C"));

        gridLayout->addWidget(C, 1, 3, 1, 1);

        CPaste = new QPushButton(tab);
        CPaste->setObjectName(QStringLiteral("CPaste"));

        gridLayout->addWidget(CPaste, 1, 1, 1, 1);

        CCopy = new QPushButton(tab);
        CCopy->setObjectName(QStringLiteral("CCopy"));

        gridLayout->addWidget(CCopy, 1, 0, 1, 1);

        CClear = new QPushButton(tab);
        CClear->setObjectName(QStringLiteral("CClear"));

        gridLayout->addWidget(CClear, 1, 2, 1, 1);

        gridLayout->setColumnStretch(3, 2);

        verticalLayout_3->addLayout(gridLayout);

        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        verticalLayout_4 = new QVBoxLayout(tab_2);
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setContentsMargins(11, 11, 11, 11);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        Dtxt = new QTextEdit(tab_2);
        Dtxt->setObjectName(QStringLiteral("Dtxt"));

        verticalLayout_4->addWidget(Dtxt);

        gridLayout_2 = new QGridLayout();
        gridLayout_2->setSpacing(6);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, -1, -1);
        DClear = new QPushButton(tab_2);
        DClear->setObjectName(QStringLiteral("DClear"));

        gridLayout_2->addWidget(DClear, 0, 2, 1, 1);

        DPaste = new QPushButton(tab_2);
        DPaste->setObjectName(QStringLiteral("DPaste"));

        gridLayout_2->addWidget(DPaste, 0, 1, 1, 1);

        DCopy = new QPushButton(tab_2);
        DCopy->setObjectName(QStringLiteral("DCopy"));

        gridLayout_2->addWidget(DCopy, 0, 0, 1, 1);

        D = new QPushButton(tab_2);
        D->setObjectName(QStringLiteral("D"));

        gridLayout_2->addWidget(D, 0, 3, 1, 1);

        gridLayout_2->setColumnStretch(3, 2);

        verticalLayout_4->addLayout(gridLayout_2);

        tabWidget->addTab(tab_2, QString());

        verticalLayout->addWidget(tabWidget);

        Limpiar = new QPushButton(centralWidget);
        Limpiar->setObjectName(QStringLiteral("Limpiar"));

        verticalLayout->addWidget(Limpiar);

        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));

        verticalLayout->addWidget(label);

        MainWindow->setCentralWidget(centralWidget);
        QWidget::setTabOrder(Limpiar, tabWidget);

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "NCMPIC Linux version (Qt 5)", Q_NULLPTR));
        label_2->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:9pt;\">Caracteres soportados: a-z a-Z .,:;!? (No acentos ni s\303\255mbolos, ni \303\261)</span></p><p><span style=\" font-size:9pt;\">(!) Oculta el acceso directo a esta aplicaci\303\263n de tu men\303\272 de aplicaciones</span></p></body></html>", Q_NULLPTR));
        C->setText(QApplication::translate("MainWindow", "Codificar", Q_NULLPTR));
        CPaste->setText(QApplication::translate("MainWindow", "Pegar", Q_NULLPTR));
        CCopy->setText(QApplication::translate("MainWindow", "Copiar", Q_NULLPTR));
        CClear->setText(QApplication::translate("MainWindow", "Limpiar", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("MainWindow", "Codificar", Q_NULLPTR));
        DClear->setText(QApplication::translate("MainWindow", "Limpiar", Q_NULLPTR));
        DPaste->setText(QApplication::translate("MainWindow", "Pegar", Q_NULLPTR));
        DCopy->setText(QApplication::translate("MainWindow", "Copiar", Q_NULLPTR));
        D->setText(QApplication::translate("MainWindow", "Decodificar", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("MainWindow", "Decodificar", Q_NULLPTR));
        Limpiar->setText(QApplication::translate("MainWindow", "Limpiar todo", Q_NULLPTR));
        label->setText(QApplication::translate("MainWindow", "Una creaci\303\263n de: Ivan Alejandro Avalos D\303\255az", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
